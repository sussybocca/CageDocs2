import fs from 'node:fs';
import path from 'node:path';
import { Header } from '@/components/Header';

function walk(dir:string, root=dir): string[] { return fs.readdirSync(dir,{withFileTypes:true}).flatMap((e)=>e.isDirectory()?walk(path.join(dir,e.name),root):[path.relative(root,path.join(dir,e.name)).replaceAll('\\','/')]); }
export const metadata = { title:'Open-source core' };
export default function SourcePage(){ const root=path.join(process.cwd(),'opensource','cage'); const files=walk(root).sort(); return <><Header/><main className="wide-page"><div className="page-kicker">MIT-LICENSED SNAPSHOT</div><h1>Open-source CAGE core</h1><p className="lede">This repository publishes the native language/compiler/law/runtime sources that define CAGE itself. Browser adapters and generated caches are not needed to understand the language semantics.</p><div className="source-stats"><div><strong>{files.length}</strong><span>published source files</span></div><div><strong>④</strong><span>current strict surface</span></div><div><strong>MIT</strong><span>repository license</span></div></div><div className="source-list">{files.map(f=><div key={f}><code>{f}</code></div>)}</div></main></>; }

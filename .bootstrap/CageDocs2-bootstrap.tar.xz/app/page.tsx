import Link from 'next/link';
import { Header } from '@/components/Header';
import { SearchBox } from '@/components/SearchBox';

export default function Home() {
  return (
    <>
      <Header />
      <main className="home">
        <section className="hero">
          <div className="hero-copy">
            <div className="kicker">CAGE V4 · GLYPH SYSTEMS LANGUAGE</div>
            <h1>Code is not accepted.<br/><span>It is admitted.</span></h1>
            <p>CAGE is a standalone, glyph-based systems language built around explicit capability authority, resource cages, ownership, emoji fault packets, a versioned Constitution, compiler Courts, and the Tribunal admission system.</p>
            <div className="hero-actions"><Link className="primary" href="/docs/quick-start/">Start learning CAGE</Link><Link className="secondary" href="/glyphs/">Explore every glyph</Link></div>
            <SearchBox />
          </div>
          <div className="hero-code" aria-label="CAGE sample">
            <div className="code-toolbar"><span>admitted.cage4</span><span>④</span></div>
            <pre>{`④🧰\n⚖️④🔸\n🧩🎬🔸\n🧾🧰\n  ✅🧬🔸\n  ✅📐🔸\n  ✅🧱🔸\n  ✅🔐🔸\n  ✅💥🔸\n  ✅🚪🔸\n🔒\n…\n🏁🧰\n  🎛️🔢3️⃣0️⃣0️⃣0️⃣0️⃣0️⃣🔸\n  ⏱️🔢8️⃣🔸\n  🧠🔢2️⃣5️⃣6️⃣🔸\n  🧵🔢4️⃣🔸\n🔒`}</pre>
          </div>
        </section>
        <section className="principles">
          <article><span>⚖️</span><h2>Constitution</h2><p>Legality is versioned and explicit. Syntax passing is only the first gate.</p></article>
          <article><span>🧿</span><h2>Tribunal</h2><p>Proof dossiers must survive cross-law consistency and admission before execution.</p></article>
          <article><span>💥</span><h2>Raw faults</h2><p>Diagnostics are emoji fault packets until your project supplies a legal decoder.</p></article>
          <article><span>🔐</span><h2>No ambient authority</h2><p>Capabilities, effects and transfers are declared and conserved.</p></article>
          <article><span>🎛️</span><h2>Resource algebra</h2><p>Work, memory, threads, handles, events and recursion are bounded.</p></article>
          <article><span>🖥️</span><h2>Real applications</h2><p>Studio displays the scene emitted by the running CAGE process—not a screenshot of source.</p></article>
        </section>
        <section className="pathway">
          <div><span>01</span><h3>Learn the glyph surface</h3><p>Understand canonical Unicode, blocks, terminators, keycap numbers and reserved glyphs.</p></div>
          <div><span>02</span><h3>Learn legality</h3><p>Build proof dossiers, fault decoders, resource ledgers, capabilities and contracts.</p></div>
          <div><span>03</span><h3>Build a real app</h3><p>Create an admitted runtime scene whose actions mutate the actual running CAGE program.</p></div>
        </section>
      </main>
    </>
  );
}

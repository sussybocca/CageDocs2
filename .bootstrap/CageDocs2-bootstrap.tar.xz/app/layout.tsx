import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'CAGE Docs', template: '%s · CAGE Docs' },
  description: 'Official documentation for CAGE V4: the strict glyph-based native systems language.',
  metadataBase: new URL('https://cage.packarcade.win')
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

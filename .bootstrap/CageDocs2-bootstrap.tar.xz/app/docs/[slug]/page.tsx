import fs from 'node:fs';
import path from 'node:path';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { DocsShell } from '@/components/DocsShell';
import { Markdown } from '@/components/Markdown';
import { docs } from '@/content/navigation';

export const dynamicParams = false;
export function generateStaticParams() { return docs.map((d) => ({ slug: d.slug })); }

function readDoc(slug: string) {
  const file = path.join(process.cwd(), 'content', 'docs', `${slug}.md`);
  if (!fs.existsSync(file)) return null;
  return fs.readFileSync(file, 'utf8');
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const doc = docs.find((d) => d.slug === params.slug);
  return { title: doc?.title ?? 'CAGE Docs', description: doc?.summary };
}

export default function DocPage({ params }: { params: { slug: string } }) {
  const source = readDoc(params.slug);
  const meta = docs.find((d) => d.slug === params.slug);
  if (!source || !meta) notFound();
  const headings = [...source.matchAll(/^##\s+(.+)$/gm)].map((m) => m[1].replace(/[`*_]/g, ''));
  return <DocsShell active={params.slug} toc={headings}><div className="doc-breadcrumb">CAGE Docs / {meta.group} / {meta.title}</div><article className="markdown"><Markdown source={source} /></article></DocsShell>;
}
